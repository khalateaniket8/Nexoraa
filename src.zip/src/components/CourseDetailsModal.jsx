import { useEffect } from "react";

const CourseDetailsModal = ({ course, onClose }) => {
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === "Escape") {
        onClose();
      }
    };

    document.addEventListener("keydown", handleEscape);

    document.body.style.overflow = "hidden";

    return () => {
      document.removeEventListener("keydown", handleEscape);
      document.body.style.overflow = "auto";
    };
  }, [onClose]);

  if (!course) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="relative bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close course details"
          className="absolute top-4 right-4 w-10 h-10 rounded-full bg-red-500 text-white hover:bg-red-600 focus:outline-none focus:ring-4 focus:ring-red-300 active:scale-95 transition"
        >
          ✕
          <span className="sr-only">Close Modal</span>
        </button>

        {/* Image */}
        <img
          src={course.image}
          alt={course.title}
          className="w-full h-64 object-cover rounded-t-2xl"
        />

        {/* Content */}
        <div className="p-6">

          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">
            {course.title}
          </h2>

          <div className="flex flex-wrap gap-3 mt-4">

            <span className="bg-blue-100 text-blue-700 px-4 py-1 rounded-full">
              {course.category}
            </span>

            <span className="bg-green-100 text-green-700 px-4 py-1 rounded-full">
              In Progress
            </span>

          </div>

          <p className="mt-6 text-gray-600 dark:text-gray-300 leading-7">
            {course.description}
          </p>

          <div className="mt-8">

            <div className="flex justify-between mb-2">
              <span className="font-semibold dark:text-white">
                Progress
              </span>

              <span className="font-semibold text-blue-600">
                {course.progress}%
              </span>
            </div>

            <div className="w-full bg-gray-300 rounded-full h-4">

              <div
                className="bg-blue-600 h-4 rounded-full transition-all duration-500"
                style={{
                  width: `${course.progress}%`,
                }}
              ></div>

            </div>

          </div>

          <div className="grid md:grid-cols-2 gap-4 mt-8">

            <div className="bg-gray-100 dark:bg-gray-800 rounded-xl p-4">
              <h3 className="font-bold mb-2 dark:text-white">
                Course Features
              </h3>

              <ul className="space-y-2 text-gray-700 dark:text-gray-300">
                <li>✔ Lifetime Access</li>
                <li>✔ HD Video Lectures</li>
                <li>✔ Download Resources</li>
                <li>✔ Practical Projects</li>
                <li>✔ Certificate</li>
              </ul>
            </div>

            <div className="bg-gray-100 dark:bg-gray-800 rounded-xl p-4">
              <h3 className="font-bold mb-2 dark:text-white">
                Skills You'll Learn
              </h3>

              <ul className="space-y-2 text-gray-700 dark:text-gray-300">
                <li>• React.js</li>
                <li>• Tailwind CSS</li>
                <li>• Components</li>
                <li>• Responsive Design</li>
                <li>• Modern UI</li>
              </ul>
            </div>

          </div>

          <div className="mt-8">

            <h3 className="text-xl font-bold dark:text-white mb-3">
              Course Description
            </h3>

            <p className="text-gray-600 dark:text-gray-300 leading-7">
              This course helps students understand the fundamentals in a
              practical way. You will build real-world projects while learning
              modern development concepts. Every topic is explained step by
              step, making it suitable for beginners as well as intermediate
              learners.
            </p>

          </div>

          <div className="mt-8 flex flex-wrap gap-4">

            <button
              className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 active:scale-95 transition"
            >
              Continue Learning
            </button>

            <button
              onClick={onClose}
              className="border border-gray-400 px-6 py-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 focus:ring-4 focus:ring-gray-300 active:scale-95 transition dark:text-white"
            >
              Close
            </button>

          </div>

        </div>
      </div>
    </div>
  );
};

export default CourseDetailsModal;