import { useState } from "react";
import { FaBell } from "react-icons/fa";
import NotificationPanel from "./NotificationPanel";

const NotificationButton = () => {
  const [isOpen, setIsOpen] = useState(false);

  // Dummy Notifications
  const notifications = [
    {
      id: 1,
      title: "New Course Available",
      message: "AWS Advanced Networking has been added.",
      time: "5 minutes ago",
      read: false,
    },
    {
      id: 2,
      title: "Course Completed",
      message: "You completed React Fundamentals.",
      time: "1 hour ago",
      read: true,
    },
    {
      id: 3,
      title: "Learning Reminder",
      message: "Continue your Tailwind CSS course.",
      time: "2 hours ago",
      read: false,
    },
    {
      id: 4,
      title: "Certificate Ready",
      message: "Your certificate is ready to download.",
      time: "Yesterday",
      read: true,
    },
    {
      id: 5,
      title: "Assignment Reminder",
      message: "Submit your LearnSphere project.",
      time: "2 days ago",
      read: false,
    },
  ];

  const unreadCount = notifications.filter(
    (item) => !item.read
  ).length;

  return (
    <div className="relative">

      {/* Notification Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition focus:outline-none focus:ring-2 focus:ring-blue-500"
        aria-label="Open notifications"
      >
        <FaBell className="text-2xl text-gray-700 dark:text-white" />

        {/* Badge */}
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-600 text-white text-xs font-bold min-w-[20px] h-5 px-1 rounded-full flex items-center justify-center">
            {unreadCount}
          </span>
        )}

        <span className="sr-only">
          Open Notifications
        </span>

      </button>

      {/* Notification Panel */}
      <NotificationPanel
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        notifications={notifications}
      />

    </div>
  );
};

export default NotificationButton;