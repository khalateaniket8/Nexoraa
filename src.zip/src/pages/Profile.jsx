import { useState, useEffect } from "react";

const Profile = () => {
  const [user, setUser] = useState({
    name: "",
    email: "",
    phone: "",
    skills: "",
  });

  useEffect(() => {
    const savedUser = JSON.parse(localStorage.getItem("user"));

    if (savedUser) {
      setUser({
        name: savedUser.name || "",
        email: savedUser.email || "",
        phone: savedUser.phone || "",
        skills: savedUser.skills || "",
      });
    }
  }, []);

  const handleChange = (e) => {
    setUser({
      ...user,
      [e.target.name]: e.target.value,
    });
  };

  const handleUpdate = (e) => {
    e.preventDefault();

    localStorage.setItem("user", JSON.stringify(user));

    alert("Profile Updated Successfully");
  };

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 py-10 px-5">

      <div className="max-w-4xl mx-auto bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden">

        {/* Header */}
        <div className="bg-blue-600 py-10 flex flex-col items-center">

          <img
            src="https://i.pravatar.cc/150?img=12"
            alt="Profile"
            className="w-32 h-32 rounded-full border-4 border-white shadow-lg"
          />

          <h1 className="text-3xl font-bold text-white mt-5">
            {user.name || "Student"}
          </h1>

          <p className="text-blue-100">
            {user.email || "student@email.com"}
          </p>

        </div>

        {/* Form */}
        <form
          onSubmit={handleUpdate}
          className="p-8"
        >

          <div className="grid md:grid-cols-2 gap-6">

            <div>

              <label className="font-semibold dark:text-white">
                Full Name
              </label>

              <input
                type="text"
                name="name"
                value={user.name}
                onChange={handleChange}
                className="w-full border rounded-lg p-3 mt-2 dark:bg-gray-700 dark:text-white"
              />

            </div>

            <div>

              <label className="font-semibold dark:text-white">
                Email
              </label>

              <input
                type="email"
                name="email"
                value={user.email}
                onChange={handleChange}
                className="w-full border rounded-lg p-3 mt-2 dark:bg-gray-700 dark:text-white"
              />

            </div>

            <div>

              <label className="font-semibold dark:text-white">
                Phone
              </label>

              <input
                type="text"
                name="phone"
                value={user.phone}
                onChange={handleChange}
                placeholder="9876543210"
                className="w-full border rounded-lg p-3 mt-2 dark:bg-gray-700 dark:text-white"
              />

            </div>

            <div>

              <label className="font-semibold dark:text-white">
                Skills
              </label>

              <input
                type="text"
                name="skills"
                value={user.skills}
                onChange={handleChange}
                placeholder="React, Node, Tailwind"
                className="w-full border rounded-lg p-3 mt-2 dark:bg-gray-700 dark:text-white"
              />

            </div>

          </div>

          {/* Statistics */}

          <div className="grid grid-cols-3 gap-5 mt-10">

            <div className="bg-blue-100 rounded-xl p-5 text-center">

              <h2 className="text-3xl font-bold text-blue-700">
                12
              </h2>

              <p>Courses</p>

            </div>

            <div className="bg-green-100 rounded-xl p-5 text-center">

              <h2 className="text-3xl font-bold text-green-700">
                5
              </h2>

              <p>Certificates</p>

            </div>

            <div className="bg-pink-100 rounded-xl p-5 text-center">

              <h2 className="text-3xl font-bold text-pink-700">
                75%
              </h2>

              <p>Progress</p>

            </div>

          </div>

          <button
            type="submit"
            className="w-full mt-10 bg-blue-600 text-white py-4 rounded-xl hover:bg-blue-700 transition"
          >
            Save Profile
          </button>

        </form>

      </div>

    </div>
  );
};

export default Profile;